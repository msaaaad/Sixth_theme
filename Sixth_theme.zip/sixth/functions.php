<?php 


	function sixth_support(){

		add_theme_support( 'title-tag' );
		add_theme_support( 'custom-header' );
		add_theme_support( 'custom-background' );
		add_theme_support( 'menus' );
		add_theme_support( 'widgets' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'post-formats',array('audio','video','gallery'));
		load_theme_textdomain('Sixth',get_template_directory().'/language');

		// register_nav_menu('main-menu','Main Menu');
		register_nav_menus(array(



			'main-menu'			=>'Main',
			'footer-menu'		=>'Footer Menu',
			'sidebar-menu'		=>'Sidebar Menu',



		));

		function default_menu(){
			if (!is_user_logged_in()) {
				echo "<ul>";
			echo "<li><a href='".home_url()."'>Home</a><li>";
			echo "</ul>";
			}
			else{
				echo "<ul>";
			echo "<li><a href='wp-admin/nav-menus.php'>Create your menu</a><li>";
			echo "</ul>";
			}
		}

		register_post_type('sixth-port',array(

			'public'				=>true,
			'labels'				=>array(

				'name'				=>__('Portfolio','Sixth'),
				'all_items'			=>__('All portfolios','Sixth'),
				'add_new'			=>__('Add portfolio','Sixth'),
				'add_new_item'		=>__('Add new portfolio','Sixth'),
				'set_featured_image'=>__('featured image add koro'),
				'remove_featured_image'=>__('featured image baad deo')

			),
			'menu_position'			=>5,
			'menu_icon'				=>'dashicons-admin-comments',
			'supports'				=>array('title','editor','thumbnail'),

		));

		register_taxonomy('portfolio-cat','sixth-port',array(

			'hierarchical'			=>true,
			'labels'				=>array(


				'name'				=>'type',
				'all_items'			=>'All types',
				'add_new'			=>'Add type',
				'add_new_item'			=>'Add new type',
			),
		));

	}

	add_action('after_setup_theme','sixth_support');

	function wp_widget(){

		register_sidebar(array(

			'name'				=>'sidebar widget',
			'id'				=>'sidebar-widget',
			'before_widget'		=>'<article class="widget">',
	 		'after_widget'		=>'</article>
<div class="divide20"></div>',
	 		'before_title'		=>'<h3 class="widget-title black">',
	 		'after_title'		=>'</h3>',

		));
		register_sidebar(array(

			'name'				=>'footer widget',
			'id'				=>'footer-widget',
			'before_widget'		=>'<article class="span3">',
			'after_widget'		=>'</article>',
	 		'before_title'		=>'<h3 class="widget-title">',
	 		'after_title'		=>'</h3>',

		));
		register_sidebar(array(

			'name'				=>'Contact widget',
			'id'				=>'contact-widget',
			'before_widget'		=>'<div class="span5 offset1">',
			'after_widget'		=>'</div>',
			'before_title'		=>'<h3 class="paragraph-title"><strong>',
			'after_title'		=>'</strong></h3>',

		));

	}

	add_action('widgets_init','wp_widget');

	function sixth_css_and_js(){

		wp_enqueue_style('six-lightbox',get_template_directory_uri().'/css/lightbox.css');
		wp_enqueue_style('six-bootstrap',get_template_directory_uri().'/css/bootstrap.css');
		wp_enqueue_style('six-fontello',get_template_directory_uri().'/css/type/fontello.css');
		wp_enqueue_style('six-style',get_template_directory_uri().'/css/style.css');
		wp_enqueue_style('six-maincss',get_stylesheet_uri());



		
				wp_enqueue_script('jquery');
		wp_enqueue_script('sx-bootstrap',get_template_directory_uri().'/js/bootstrap.min.js','array("jquery")','',true);
		wp_enqueue_script('sx-overscroll',get_template_directory_uri().'/js/jquery.overscroll.min.js','array("jquery")','',true);
		wp_enqueue_script('sx-themepunch',get_template_directory_uri().'/js/jquery.themepunch.plugins.min.js','array("jquery")','',true);
		wp_enqueue_script('sx-showbizpro',get_template_directory_uri().'/js/jquery.themepunch.showbizpro.js','array("jquery")','',true);
		wp_enqueue_script('sx-twitter',get_template_directory_uri().'/js/jquery.twitter.min.js','array("jquery")','',true);
		wp_enqueue_script('sx-jscrollpane',get_template_directory_uri().'/js/jquery.jscrollpane.min.js','array("jquery")','',true);
		wp_enqueue_script('sx-mousewheel',get_template_directory_uri().'/js/jquery.mousewheel.min.js','array("jquery")','',true);
		wp_enqueue_script('sx-portfolio',get_template_directory_uri().'/js/jquery.fh.portfolio.js','array("jquery")','',true);
		wp_enqueue_script('sx-retina',get_template_directory_uri().'/js/retina.js','array("jquery")','',true);
		wp_enqueue_script('sx-mediaelement',get_template_directory_uri().'/js/mediaelement-and-player.min.js','array("jquery")','',true);
		wp_enqueue_script('sx-FitVids',get_template_directory_uri().'/js/FitVids.js','array("jquery")','',true);
		wp_enqueue_script('sx-jribbble',get_template_directory_uri().'/js/jquery.jribbble-0.11.0.ugly.js','array("jquery")','',true);
		wp_enqueue_script('sx-dcflickr',get_template_directory_uri().'/js/jquery.dcflickr.1.0.js','array("jquery")','',true);
		wp_enqueue_script('sx-forms',get_template_directory_uri().'/js/forms.js','array("jquery")','',true);
		wp_enqueue_script('sx-screen',get_template_directory_uri().'/js/screen.js','array("jquery")','',true);
		wp_enqueue_script('sx-lightbox',get_template_directory_uri().'/js/lightbox.js','array("jquery")','',true);

	}

	add_action('wp_enqueue_scripts','sixth_css_and_js');

	// cmb2 custom metabox file require

	require_once('lib/init.php');
	require_once('lib/config.php');

	//tgm plugin activator activation

	require_once('plugin/config.php');

	// redux framework require

	require_once('inc/ReduxCore/framework.php');
	require_once('inc/sample/config.php');

	//shortcode

	require_once('inc/shortcode.php');

