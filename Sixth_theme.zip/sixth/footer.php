<footer><?php global $sixth; ?>
			<section class="footer" style="background-color: <?php echo $sixth['main-footer-color']; ?>">
				<!-- A SPECIAL FOOTER FOR 4 - 8 SPAN LEFT SIDE !! -->
				<div class="container">
					<div class="row">

						<?php dynamic_sidebar('footer-widget'); ?>

						
					</div>
				</div>
			</section>


			<section class="subfooter" style="background-color: <?php echo $sixth['main-footer-color']; ?>">
				<div class="container">
					<div class="one_third">
						<p class="small"><?php echo $sixth['copy-text']; ?></p>
					</div>

					<div class="one_third">
						<p class="small"><?php echo $sixth['policy-text']; ?></p>
					</div>

					<div class="one_third lastcolumn">
						<div class="rightfloat">
								<!-- SOCIALS -->
								<?php if($sixth['icon-show-hider']==1): ?>
								<ul class="socials fadegroup">
									<?php if($sixth['so-link']['facebook']): ?>
											<li class="reversefadeitem">
													<a href="<?php echo $sixth['so-link']['facebook']; ?>">
														<div class="soc facebook">
															<div class="bg"></div>
														</div>
													</a>
											</li>
										<?php endif; ?>


									<?php if($sixth['so-link']['twitter']): ?>
											<li class="reversefadeitem">
													<a href="<?php echo $sixth['so-link']['twitter']; ?>">
														<div class="soc twitter">
															<div class="bg"></div>
														</div>
													</a>
											</li>
										<?php endif; ?>


									<?php if($sixth['so-link']['skype']): ?>
											<li class="reversefadeitem">
													<a href="<?php echo $sixth['so-link']['skype']; ?>">
														<div class="soc skype">
															<div class="bg"></div>
														</div>
													</a>
											</li>
										<?php endif; ?>


									<?php if($sixth['so-link']['dribble']): ?>
											<li class="reversefadeitem">
													<a href="<?php echo $sixth['so-link']['dribble']; ?>">
														<div class="soc dribbble">
															<div class="bg"></div>
														</div>
													</a>
											</li>
										<?php endif; ?>


									<?php if($sixth['so-link']['flickr']): ?>
											<li class="reversefadeitem">
													<a href="<?php echo $sixth['so-link']['flickr']; ?>">
														<div class="soc flickr">
															<div class="bg"></div>
														</div>
													</a>
											</li>
										<?php endif; ?>


									<?php if($sixth['so-link']['youtube']): ?>
											<li class="reversefadeitem">
													<a href="<?php echo $sixth['so-link']['youtube']; ?>">
														<div class="soc youtube">
															<div class="bg"></div>
														</div>
													</a>
											</li>
										<?php endif; ?>
								  </ul><!-- END OF SOCIALS -->
								<?php endif; ?>
							</div>
					</div>
					<div class="clear"></div>
				</div>
			</section>

		</footer>
	</section><!-- THE END OF THE BOXED WRAPPER -->

<?php wp_footer(); ?>
  </body>
</html>