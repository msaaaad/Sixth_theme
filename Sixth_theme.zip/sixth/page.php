<?php get_header(); ?>
<!-- HORIZONTAL DIVIDER WITH ICON AND TEXT --><!-- THE MAIN INTRO TEXT -->
<?php get_template_part('/template/header-template'); ?>
			
		<div class="divide30"></div>

			<!-- THE SIDEBAR HELPER ROW CONTAINER -->
			<div class="row">

				<!-- THE CONTENT PART WITH SIDEBAR -->
				<section class="span9 leftfloat withsidebar">
					<?php if(have_posts()): ?>
					<?php while(have_posts()):the_post(); ?>

							<!-- A NEW BLOG POST ARTICLE -->
							<article class="blogpost">
								<!-- TABLE VIEW FOR BLOG POST -->

							<section class="media-wrapper">
									<div class="mediaholder">
										<a href="#"><?php the_post_thumbnail(); ?></a>
										<div class="hovercover">
											<a href="#"><div class="linkicon notalone"><i class="icon-link-1 white"></i></div></a>
											<a
											data-lightbox="image-1" href="<?php echo wp_get_attachment_image_url(get_post_thumbnail_id(),'full');?>"><div class="lupeicon notalone"><i class="icon-search-1 white"></i></div></a>
										</div>
									</div>
							</section>

									<!-- BLOG CONTENT -->
									<div class="divide20"></div>
									<p class="small darkgray"><?php echo wp_trim_words(get_the_content(),'50','</p>
									<div class="divide20"></div>
									<a href="'.get_the_permalink().'" class="btn small maincolor witharrow">Read More</a>'); ?>  

							</article> <!-- END OF BLOG POST ARTICLE -->


						<?php endwhile; ?>

						<?php the_posts_pagination(array(

							'screen_reader_text'	=>' ',
							'prev_text'				=>'<a href="#" class="btn small gray withleftarrow"><span class="bold">Previous</span></a>',
							'next_text'				=>'<a href="#" class="btn small gray witharrow"><span class="bold">next</span></a>',


						)); ?>
						<?php else: ?>
						<h1 style="color: red;"><b>Opps! Post not found found | 404 ERROR  </b></h1>
						<h3>please go on <a href=" <?php echo  home_url(); ?>">home</a></h3>

						<?php endif; ?>

				</section> <!-- END OF THE CONTENT PART -->

				<!-- THE SIDEBAR -->
				<aside class="span3 graybg sidebar rightfloat">
			<?php get_sidebar(); ?>
			</aside><!-- END OF THE SIDEBAR -->
			</div> <!-- END OF THE ROW CONTAINER -->

		</section><!-- END OF CONTAINER -->
	</section><!-- END OF CONTENT -->

 	</section> <!-- END OF MAIN CONTENT HERE -->

		<?php get_footer(); ?>