<?php 

function sixth_portfolio(){

ob_start();
?>
<?php

// Template Name: portfolio page
 get_header(); ?>

						<?php get_template_part('/template/header-template'); ?>


			<div class="divide30"></div>

				<!-- THE PORTFOLIO INTRO WITH SOME CONTENT AT THE TOP -->
		<?php while(have_posts()):the_post(); ?>
			<div class="one_third">
				<h2 class="article-title"><?php the_title(); ?></h2>
				<p><?php the_content(); ?></p>
				<div class="divide20"></div>
				
			</div>
			<?php endwhile; ?>

			<div class="two_third lastcolumn">
				<!-- THE FEATURED ARTICLE SLIDER -->
								<article class="featured-article-horslider">

										<div id="myCarousel" class="carousel slide">

											<!-- THE INDICATORS (BULLETS) -->

				
				  <div class="carousel-inner">
				  	<?php

				  	$imageport=new WP_Query(array(
				  		'post_type'		=>'sixth-port',
				  		'post_per_page'	=>-1,
				  	));

				  	 while($imageport->have_posts()):$imageport->the_post(); ?>
					    <div class=" item">
					    	<div class="mediaholder">
					    		<div class="maxheight-wrapper">
									<?php the_post_thumbnail(); ?>
					    		</div>

							</div>
							<div class="detailholder gray-boxed">
								<h4 class="showbiz-title txt-left nobottommargin"><a href="#" class="black"><?php the_title(); ?></a></h4>
								<div class="divide5"></div>
								<p class="txt-left"><?php $category= get_the_terms(get_the_id(),'portfolio-cat');

								foreach($category as $cat){

									echo $cat->slug.' ';
								}

								 ?></p>
							</div>
					    </div>
					<?php endwhile; ?>
					    
				   </div>


				  <!-- Carousel nav (IN CASE IT NEEDED, REMOVE COMMENTS BELOW)  -->
											  <a class="carousel-control left" href="#myCarousel" data-slide="prev">&lsaquo;</a>
											  <a class="carousel-control right" href="#myCarousel" data-slide="next">&rsaquo;</a>
									</div>

								</article>
			</div>
			<div class="clear"></div><!-- END OF THE PORTFOLIO INTRO -->


			<!-- THE PORTFOLIO GRID ITSELF -->

			<div class="divide20"></div>

			<!-- HORIZONTAL DIVIDER WITH ICON AND TEXT -->
			<div class="table bottomhr smartdivider">
				<div class="table-cell rp10">
						<i class="icon-cog small coloredbottomhr"></i>
				</div>

				<div class="table-cell fullwidth txt-center portfolio_selector_boss">
						<a class="portfolio_selector " data-group="all-group" href="#"><span class="verysmall  nobreak lightgray portfolio_selector_inner"><strong>ALL</strong></span></a>

						<?php $category=get_terms('portfolio-cat');

						foreach($category as $cccc): ?>
						<a class="portfolio_selector  cat1-group" data-group="<?php echo $cccc->slug; ?>" href="#"><span class="verysmall  nobreak lightgray portfolio_selector_inner"><strong><?php echo $cccc->name; ?></strong></span></a>
						
					<?php endforeach; ?>
				</div>

				<div class="table-cell">
					<p class="verysmall  lh30 coloredbottomhr nobreak"><strong>OUR WORK</strong></p>
				</div>
			</div><!-- END OF SMART DIVIDER -->


			<!-- THE PORTFOLIO -->
			<div class="divide30"></div>
					<!--	THE PORTFOLIO ENTRIES	-->
							<section class="row portfolio portfolio_rotator hoverable teaser_rotator">
									<ul>
										<?php $blogpost=new WP_Query(array(

											'post_type'				=>'sixth-port',
										)); ?>
		
										<?php while($blogpost->have_posts()):$blogpost->the_post(); ?>
										<li class="span3 theportfolio all-group <?php $category= get_the_terms(get_the_id(),'portfolio-cat');

								foreach($category as $cat){

									echo $cat->slug.' ';
								}

								 ?>" >

														<section class="media-wrapper">
																<div class="mediaholder portfoliosss">
																	<a href="#"><?php the_post_thumbnail(); ?></a>
																	<div class="hovercover">
																		<a href="#"><div class="linkicon notalone"><i class="icon-link-1 white"></i></div></a>
																		<a
											data-lightbox="image-1" href="<?php echo wp_get_attachment_image_url(get_post_thumbnail_id(),'full');?>"><div class="lupeicon notalone"><i class="icon-search-1 white"></i></div></a>
																	</div>
																</div>
														</section>

														<div class="detailholder gray-boxed">
															<h4 class="showbiz-title txt-left nobottommargin"><a href="#" class="black"><?php the_title(); ?></a></h4>
															<div class="divide5"></div>
															<p class="txt-left"><?php $category= get_the_terms(get_the_id(),'portfolio-cat');


															foreach($category as $cat)

															{
																echo $cat->name.' ';
															}
															 ?></p>
														</div>
										</li>

								<?php endwhile; ?>
										
									</ul>
									<div class="clear"></div>
							</section>
							<div class="clear"></div>
					<!-- END OF THE PORTFOLIO -->
				<div class="divide30"></div>
		</section><!-- END OF CONTAINER -->
	</section><!-- END OF CONTENT -->



 	</section> <!-- END OF MAIN CONTENT HERE -->

		<?php get_footer(); ?>

<?php 
return ob_get_clean();
}
add_shortcode('hss','sixth_portfolio');

if(function_exists(vc_map)){

	vc_map(array(

		'name'			=>'portfolio',
		'base'			=>'hss',
	));
}

function sixth_contact(){

ob_start();
?>
<?php

// Template Name:Contact
 get_header(); ?>
<?php get_template_part('/template/header-template'); ?>


			<div class="divide30"></div>


			<?php while(have_posts()):the_post(); ?>
				<?php the_content(); ?>
			<?php endwhile; ?>


			<div class="divide50"></div>
			<div class="row">
				<!-- THE CONTACT FORM -->
				<div class="span5">
					<h3 class="paragraph-title"><strong>Send us a Quick Message</strong></h3>
					<?php while(have_posts()):the_post(); ?>
					<?php echo do_shortcode(get_post_meta(get_the_id(),'contact-form',true)); ?>
					<?php endwhile; ?>
					
				</div>
				<?php dynamic_sidebar('contact-widget'); ?>
				
			</div>


			<div class="divide30"></div>

		</section> <!-- END OF THE CONTENT PART -->

	</section><!-- END OF CONTAINER -->

 	</section> <!-- END OF MAIN CONTENT HERE -->

		<?php get_footer(); ?>

<?php 
return ob_get_clean();
}
add_shortcode('hcc','sixth_contact');

if(function_exists(vc_map)){

	vc_map(array(

		'name'			=>'contact',
		'base'			=>'hcc',
	));
}

function sixth_about(){

ob_start();
?>
<?php get_header(); ?>
<!-- HORIZONTAL DIVIDER WITH ICON AND TEXT --><!-- THE MAIN INTRO TEXT -->
<?php get_template_part('/template/header-template'); ?>
			
		<div class="divide30"></div>

			<!-- THE SIDEBAR HELPER ROW CONTAINER -->
			<div class="row">

				<!-- THE CONTENT PART WITH SIDEBAR -->
				<section class="span9 leftfloat withsidebar">
					<?php if(have_posts()): ?>
					<?php while(have_posts()):the_post(); ?>

							<!-- A NEW BLOG POST ARTICLE -->
							<article class="blogpost">
								<!-- TABLE VIEW FOR BLOG POST -->

							<section class="media-wrapper">
									<div class="mediaholder">
										<a href="#"><?php the_post_thumbnail(); ?></a>
										<div class="hovercover">
											<a href="#"><div class="linkicon notalone"><i class="icon-link-1 white"></i></div></a>
											<a
											data-lightbox="image-1" href="<?php echo wp_get_attachment_image_url(get_post_thumbnail_id(),'full');?>"><div class="lupeicon notalone"><i class="icon-search-1 white"></i></div></a>
										</div>
									</div>
							</section>

									<!-- BLOG CONTENT -->
									<div class="divide20"></div>
									<p class="small darkgray"><?php echo wp_trim_words(get_the_content(),'50','</p>
									<div class="divide20"></div>
									<a href="'.get_the_permalink().'" class="btn small maincolor witharrow">Read More</a>'); ?>  

							</article> <!-- END OF BLOG POST ARTICLE -->


						<?php endwhile; ?>

						<?php the_posts_pagination(array(

							'screen_reader_text'	=>' ',
							'prev_text'				=>'<a href="#" class="btn small gray withleftarrow"><span class="bold">Previous</span></a>',
							'next_text'				=>'<a href="#" class="btn small gray witharrow"><span class="bold">next</span></a>',


						)); ?>
						<?php else: ?>
						<h1 style="color: red;"><b>Opps! Post not found found | 404 ERROR  </b></h1>
						<h3>please go on <a href=" <?php echo  home_url(); ?>">home</a></h3>

						<?php endif; ?>

				</section> <!-- END OF THE CONTENT PART -->

				<!-- THE SIDEBAR -->
				<aside class="span3 graybg sidebar rightfloat">
			<?php get_sidebar(); ?>
			</aside><!-- END OF THE SIDEBAR -->
			</div> <!-- END OF THE ROW CONTAINER -->

		</section><!-- END OF CONTAINER -->
	</section><!-- END OF CONTENT -->

 	</section> <!-- END OF MAIN CONTENT HERE -->

		<?php get_footer(); ?>

<?php 
return ob_get_clean();

}
add_shortcode('haa','sixth_about');

if(function_exists(vc_map)){

	vc_map(array(

		'name'			=>'about',
		'base'			=>'haa',
	));
}






// function sixth_contact(){

// ob_start();
// ?>


// <?php 
// return ob_get_clean();
// }
// add_shortcode('hss','sixth_contact');

// if(function_exists(vc_map)){

// 	vc_map(arraya9(

// 		'name'			=>'contact',
// 		'base'			=>'hss',
// 	));
// }








 ?>