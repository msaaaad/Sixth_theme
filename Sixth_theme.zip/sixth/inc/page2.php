<?php 

//Template Name:page2
get_header();
 ?>

<div class="divide50"></div>
<div class="divide50"></div>

<?php while(have_posts()):the_post(); ?>
	<?php the_content(); ?>
<?php endwhile; ?>

<div class="divide50"></div>
<div class="divide50"></div>

 <?php get_footer(); ?>