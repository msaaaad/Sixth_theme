<?php

// Template Name:Contact
 get_header(); ?>
<?php get_template_part('/template/header-template'); ?>


			<div class="divide30"></div>


			<?php while(have_posts()):the_post(); ?>
				<?php the_content(); ?>
			<?php endwhile; ?>


			<div class="divide50"></div>
			<div class="row">
				<!-- THE CONTACT FORM -->
				<div class="span5">
					<h3 class="paragraph-title"><strong>Send us a Quick Message</strong></h3>
					<?php while(have_posts()):the_post(); ?>
					<?php echo do_shortcode(get_post_meta(get_the_id(),'contact-form',true)); ?>
					<?php endwhile; ?>
					
				</div>
				<?php dynamic_sidebar('contact-widget'); ?>
				
			</div>


			<div class="divide30"></div>

		</section> <!-- END OF THE CONTENT PART -->

	</section><!-- END OF CONTAINER -->

 	</section> <!-- END OF MAIN CONTENT HERE -->

		<?php get_footer(); ?>