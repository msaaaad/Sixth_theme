
<div class="innerwrapper heightadjustter">
	<?php dynamic_sidebar('sidebar-widget'); ?>
		<!-- THE SIMPLE FEATURED WORK MEdIA HOLDER
		<article class="widget widget-list">
			<h3 class="widget-title black">Text</h3>
			<p class="small">Nulla auctor dictum turpis molestie adipiscing. Etiam in mauris turpis. Praesent aliquet, mi a scelerisque tristique, erat turpis euismod urna, eu adipiscing sapien lectus at ante. Nulla nunc odio, pretium vitae porttitor a, commodo nec turpis. </p>
		</article> -->
</div><!-- END OF INNER WRAPER AND HIGHT JUSTIFIER -->