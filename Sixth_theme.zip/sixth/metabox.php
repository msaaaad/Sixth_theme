<?php

// Template Name:Metabox
 get_header(); ?>
<?php get_template_part('/template/header-template'); ?>


			<div class="divide30"></div>


			<?php while(have_posts()):the_post(); ?>
				<?php the_content(); ?>
			<?php endwhile; ?>


			<div class="divide50"></div>
			<div class="row">

				<?php if(get_post_meta(get_the_id(),'text-checkbox',true)):  ?>
				
				<p>Anika <span style="color: <?php echo get_post_meta(get_the_id(),'text-colorpicker',true); ?> "><?php echo ' '. get_post_meta(get_the_id(),'text-radio_inline',true) ?></span></p>
				<img src=" <?php echo get_post_meta(get_the_id(),'text-file',true); ?> " alt="">
				<?php echo wp_oembed_get(get_post_meta(get_the_id(),'text-oembed',true));

				 ?>
				 <br>

				<?php $onkgula=get_post_meta(get_the_id(),'text-file_list',true);

				foreach ($onkgula as $onk) {
					echo "<img style='height:300px;width:450px;' src='".$onk."' alt=''><br>";
				};

				 ?>

			<?php endif; ?>
				
			</div>


			<div class="divide30"></div>

		</section> <!-- END OF THE CONTENT PART -->

	</section><!-- END OF CONTAINER -->

 	</section> <!-- END OF MAIN CONTENT HERE -->

		<?php get_footer(); ?>