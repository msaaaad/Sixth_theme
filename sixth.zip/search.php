<?php get_header(); ?>
<!-- HORIZONTAL DIVIDER WITH ICON AND TEXT --><!-- THE MAIN INTRO TEXT -->
<?php get_template_part('/template/header-template'); ?>
			
		<div class="divide30"></div>

			<!-- THE SIDEBAR HELPER ROW CONTAINER -->
			<div class="row">

				<!-- THE CONTENT PART WITH SIDEBAR -->
				<section class="span9 leftfloat withsidebar">
					<?php if(have_posts()): ?>
					<?php while(have_posts()):the_post(); ?>

							<!-- A NEW BLOG POST ARTICLE -->
							<article class="blogpost">
								<!-- TABLE VIEW FOR BLOG POST -->


									<h2 class="blog-title"><?php the_title(); ?></h2>
									<div class="divide5"></div>
									<!-- BLOG ATTRIBUTES -->
										<div class="gray-boxed verysmall gray leftfloat rm5 bm5"><i class="icon-calendar small  rm10"></i><?php the_time('M j, Y'); ?></div>
										<div class="gray-boxed verysmall gray leftfloat rm5 bm5"><i class="icon-user small  rm10"></i><?php the_author(); ?></div>
										<div class="gray-boxed verysmall gray leftfloat rm5 bm5"><i class="icon-comment small  rm10"></i><?php comments_popup_link('No comment','1 comment','% comments','salauddin-kader','<span style="cursor:not-allowed;">Comments not allowed</span>'); ?></div>
										<?php the_tags('<div class="gray-boxed verysmall gray leftfloat rm5 bm5"><i class="icon-tag small  rm10"></i>',',','</div><div class="clear"></div><div class="divide10"></div>'); ?>
									<!-- END OF BLOG ATTRIBUTES -->

									<div class="divide20"></div>

									<!-- BLOG MEDIA -->
							<section class="media-wrapper">
									<div class="mediaholder">
										<a href="#"><?php the_post_thumbnail(); ?></a>
										<div class="hovercover">
											<a href="#"><div class="linkicon notalone"><i class="icon-link-1 white"></i></div></a>
											<a
											data-lightbox="image-1" href="<?php echo wp_get_attachment_image_url(get_post_thumbnail_id(),'full');?>"><div class="lupeicon notalone"><i class="icon-search-1 white"></i></div></a>
										</div>
									</div>
							</section>

									<!-- BLOG CONTENT -->
									<div class="divide20"></div>
									<p class="small darkgray"><?php echo wp_trim_words(get_the_content(),'50','</p>
									<div class="divide20"></div>
									<a href="'.get_the_permalink().'" class="btn small maincolor witharrow">Read More</a>'); ?>  

							</article> <!-- END OF BLOG POST ARTICLE -->


							<div class="divide60"></div>
							<hr>
							<div class="divide10"></div>
						<?php endwhile; ?>

						<?php the_posts_pagination(array(

							'screen_reader_text'	=>' ',
							'prev_text'				=>'<a href="#" class="btn small gray withleftarrow"><span class="bold">Previous</span></a>',
							'next_text'				=>'<a href="#" class="btn small gray witharrow"><span class="bold">next</span></a>',


						)); ?>
						<?php else: ?>
						<h1 style="color: red;"><b>Opps! Post not found found | 404 ERROR  </b></h1>
						<h3>please go on <a href=" <?php echo  home_url(); ?>">home</a></h3>

						<?php endif; ?>

				</section> <!-- END OF THE CONTENT PART -->

				<!-- THE SIDEBAR -->
				<aside class="span3 graybg sidebar rightfloat">
			<?php get_sidebar(); ?>
			</aside><!-- END OF THE SIDEBAR -->
			</div> <!-- END OF THE ROW CONTAINER -->

		</section><!-- END OF CONTAINER -->
	</section><!-- END OF CONTENT -->

 	</section> <!-- END OF MAIN CONTENT HERE -->

		<?php get_footer(); ?>