<?php

//Template Name: Left sidebar
 get_header(); ?>
 <?php get_template_part('/template/header-template'); ?>

			<div class="divide30"></div>


			<!-- THE SIDEBAR HELPER ROW CONTAINER -->
			<div class="row">
				<!-- THE SIDEBAR -->
			<aside class="span3 graybg sidebar leftfloat">

				<?php get_sidebar(); ?>
			</aside>
					

				<!-- THE CONTENT PART WITH SIDEBAR -->
				<section class="span9 rightfloat withsidebar">
									<?php while(have_posts()):the_post(); ?>

							<!-- A NEW BLOG POST ARTICLE -->
							<article class="blogpost">
								<!-- TABLE VIEW FOR BLOG POST -->


									<!-- BLOG MEDIA -->
							<section class="media-wrapper">
									<div class="mediaholder">
										<a href="#"><?php the_post_thumbnail(); ?></a>
										<div class="hovercover">
											<a href="#"><div class="linkicon notalone"><i class="icon-link-1 white"></i></div></a>
											<a
											data-lightbox="image-1" href="<?php echo wp_get_attachment_image_url(get_post_thumbnail_id(),'full');?>"><div class="lupeicon notalone"><i class="icon-search-1 white"></i></div></a>
										</div>
									</div>
							</section>

									<!-- BLOG CONTENT -->
									<div class="divide20"></div>
									<?php the_content(); ?>
									
							</article> <!-- END OF BLOG POST ARTICLE -->
						<div class="divide20"></div>
						<div class="divide20"></div>
						<div class="divide20"></div>


						<?php endwhile; ?>





				</section> <!-- END OF THE CONTENT PART -->
				
			</div> <!-- END OF THE ROW CONTAINER -->

		</section><!-- END OF CONTAINER -->
	</section><!-- END OF CONTENT -->

 	</section> <!-- END OF MAIN CONTENT HERE -->

		<?php get_footer(); ?>