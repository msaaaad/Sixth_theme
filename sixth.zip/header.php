<!DOCTYPE html>
<html lang="en" <?php global $sixth; language_attributes(); ?> >
  <head>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!--meta http-equiv="X-UA-Compatible" content="IE=edge" /-->

    <meta name="description" content="">
    <meta name="author" content="">


    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $sixth['fav-image']['url']; ?>">
	<?php wp_head(); ?>
  </head>


<!-- ADD class="boxedlayout" IN CASE THE SITE SHOULD BE BOXED -->
  <body class="boxedlayout orange bg9" style="

	background:<?php echo $sixth['bg-option']['background-color']; ?>;
	background-size:<?php echo $sixth['bg-option']['background-size']; ?>;
	background-position:<?php echo $sixth['bg-option']['background-position']; ?>;
	background-attachment:<?php echo $sixth['bg-option']['background-attachment']; ?>;
	background-repeat:<?php echo $sixth['bg-option']['background-repeat']; ?>;
	background-image:url(<?php echo $sixth['bg-option']['background-image']; ?>);

  ">
  <style>
  	
	<?php echo $sixth['aceeditor']; ?>

	
body{
	font-size: <?php echo $sixth['extra-typography']['font-size'];?>;
	font-family: <?php echo $sixth['extra-typography']['font-family'];?>;
	font-weight: <?php echo $sixth['extra-typography']['font-weight'];?>;
	text-align: <?php echo $sixth['extra-typography']['text-align'];?>;
	color: <?php echo $sixth['extra-typography']['color'];?>;
	line-height: <?php echo $sixth['extra-typography']['line-height'];?>;

	 }

  </style>


		<!-- THE CONFIGURATOR FOR PREVIEW -->
		<div id="config-wrapper">
			<div id="config-menu">
				<div class="config-closer"><i class="icon-cog white medium tm7 lm7"></i></div>
				<div class="config-menuheader">SIXTH Demo Options</div>
				<ul>

					<li class="config-mainmenu">Select Size</li>
					<li class="size-switch selectedss" data-size="boxedlayout">Boxed</li>
					<li class="size-switch " data-size="">Full Width</li>

					<li class="config-mainmenu">Select Highlight Color</li>
					<li style="padding:18px" class="highlightcolors">
						<div class="config-color cc1" data-hex="99cc33" data-class="green"></div>
						<div class="config-color cc2" data-hex="52bde9" data-class="blue"></div>
						<div class="config-color cc3 " data-hex="f23535" data-class="red"></div>
						<div class="config-color cc4 selectedcc" data-hex="f27935" data-class="orange"></div>
						<div class="config-color cc5" data-hex="0ea5a0" data-class="ocean"></div>
						<div class="clear"></div>
					</li>

					<li class="config-mainmenu">Select Background</li>
					<li style="padding:18px" class="backgroundimages">
						<div class="bg-image bg1 selectedcc" data-bg="arches"></div>
						<div class="bg-image bg2" data-bg="dark_Tire"></div>
						<div class="bg-image bg3 selectedcc" data-bg="diamond_upholstery"></div>
						<div class="bg-image bg4" data-bg="escheresque_ste"></div>
						<div class="bg-image bg5" data-bg="escheresque"></div>
						<div class="clear"></div>
						<div class="bg-image bg6" data-bg="kindajean"></div>
						<div class="bg-image bg7" data-bg="pinstriped_suit"></div>
						<div class="bg-image bg8" data-bg="pw_maze_white"></div>
						<div class="bg-image bg9" data-bg="retina_wood"></div>
						<div class="bg-image bg10 " data-bg="subtle_stripes"></div>



						<div class="clear"></div>
					</li>
				</ul>
			</div>
		</div>


	  	<!-- THE RESPONSIVE MENU ON THE TOP -->
		<div class="responsive_wrapper">
			<div id="responsive-menu">
				<div class="resp-closer"><i class="txt-center icon-cancel-1 white medium lm10 tm10"></i></div>
				<div class="resp-menuheader">Sixth</div>
				<ul>
				</ul>
			</div>
		</div>

	<!-- THIS IS THE WRAPPER FOR THE FULL TEMPLAGE -->
	<section class="boxed-wrapper">

		<!-- THE STICKY MENU AT THE TOP  -->
		<header class="header" style="

		border-style:<?php echo $sixth['brdr']['border-style']; ?> ;
		border-top-width:<?php echo $sixth['brdr']['border-top']; ?> ;
		border-color:<?php echo $sixth['brdr']['border-color']; ?> ;

		">



			<!-- THE HEADER WRAP -->
			<section class="header_wrapper" style="background-color:<?php echo $sixth['top-bar-color']; ?>;">
				<div class="container">
					<div class="row">
							<!-- THE LOGO HOLDER -->
							<div class="span2">
								<div class="logoholder">
									<a href=" <?php home_url(); ?> ">
										<?php if($sixth['logo-image']['url']): ?>

										<img src="<?php echo $sixth['logo-image']['url']; ?>" alt="tenor logo">
										<?php else: ?>

										<h2><?php echo $sixth ['logo-text'] ; ?></h2>
									<?php endif; ?>


									</a>
								</div>
							</div>
							<!-- END OF LOGO HOLDER -->

							<div class="span10">
								<div id="nav" class="hidden-phone">
							<?php wp_nav_menu(array(

								'theme-location'		=>'main-menu',// menu anar jonno
								'container'				=>false,
								'fallback_cb'			=>'default_menu'

							)); ?>
												
								<div class="resp-navigator reversefadeitem"><i class="icon-menu medium gray"></i></div>
							</div><!-- END OF NAVIGTION HOLDER -->
						</div> <!-- END OF ROW -->
				</div> <!-- END OF CONTAINER -->
			</section> <!-- END OF HEADER WRAPPER  -->

		</header>


		<!-- THE CONTENT -->
		<section class="maincontent">






	<!-- THE CONTENT -->
	<section>
		<section class="container">
			<!-- THE CONTENT HEADER -->
