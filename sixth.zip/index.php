<?php get_header(); ?>
					<!-- THE MAIN INTRO TEXT -->
<article>
	<div class="divide20"></div>
	<div class="row">
		<div class="span8">
			<h1 class="bigintro txt-left leftfloat rm20 nobottommargin"><?php bloginfo('title'); ?></h1><p class="leftfloat tm15 bm15 big"><?php bloginfo('description'); ?></p>
			<div class="clear"></div>
		</div>
		<?php if($sixth['search-show-hide']==1): ?>
		<div class="span4">
			<form action=" <?php echo home_url(); ?>" role="search" method="get" id="searchform">
							<input type="text" id="Form_Search" class="searchinput" name="s" value="Search the site">
							<input type="submit" id="Form_Go" class="icon-search" name="go" value="">
							<i class="icon-search medium"></i>
							<div class="clear"></div>
			</form>
		</div>
	<?php endif; ?>
	</div>

	<hr class="nobottommargin">
	<div class="divide2"></div>


	<!-- HORIZONTAL DIVIDER WITH ICON AND TEXT -->
	<div class="table bottomhr smartdivider">
		<div class="table-cell rp10">
				<p class="verysmall lh30"><strong>HOME</strong></p>
		</div>
		<div class="table-cell">
				<p class="verysmall  lh30 coloredbottomhr nobreak">BLOG</p>
		</div>

		<div class="table-cell fullwidth">
		</div>

		<div class="table-cell">
			<p class="verysmall  lh30 coloredbottomhr nobreak"><strong>BREADCRUMB</strong></p>
		</div>
	</div>

	<div class="divide10"></div>
</article>
			<!-- END OF THE CONTENT HEADER -->
			

			<div class="divide30"></div>


			<!-- THE SIDEBAR HELPER ROW CONTAINER -->
			<div class="row">

				<!-- THE CONTENT PART WITH SIDEBAR -->
				<section class="span9 leftfloat withsidebar">
										<?php if(have_posts()): ?>
										<?php while(have_posts()):the_post(); ?>

								<!-- A NEW BLOG POST ARTICLE -->
								<article class="blogpost">
									<!-- TABLE VIEW FOR BLOG POST -->
									<div class="table-blogarticle">

										<!-- THE MEDIA HOLDER TABLE CELL -->
										<div class="media-table-cell-">
											<!-- BLOG IMAGE -->
											<section class="media-wrapper">
													<div class="mediaholder">
														<a href="#"><?php the_post_thumbnail(); ?></a>
														<div class="hovercover">
															<a href="#"><div class="linkicon notalone"><i class="icon-link-1 white"></i></div></a>
															<a href="<?php echo wp_get_attachment_image_url(get_post_thumbnail_id(),'full');?>" data-lightbox="image-1"><div class="lupeicon notalone"><i class="icon-search-1 white"></i></div></a>
														</div>
													</div>
											</section>
										</div><!-- END OF MEDIA HOLDER TABLE CELL -->

										<div class="divide20 visible-phone"></div>
										<!-- THE CONTENT HOLDER TABLE CELL -->
										<div class="blogcontent-table-cell">
											<h2 class="blog-title"><?php the_title(); ?></h2>
											<div class="divide10"></div>
											<p class="small darkgray"><?php echo wp_trim_words(get_the_content(),'100','<div class="divide10"></div><a href="'.get_the_permalink().'" class="btn small maincolor witharrow">Read More</a>'); ?></p>
											
											
										</div><!-- END OF CONTENT HOLDER TABLE CELL-->
									</div>

									<div class="divide20"></div>
									<!-- BLOG ATTRIBUTES -->
									<div class="gray-boxed verysmall gray leftfloat rm5 bm5"><i class="icon-calendar small  rm10"></i><?php the_time('M j, Y'); ?></div>
									<div class="gray-boxed verysmall gray leftfloat rm5 bm5"><i class="icon-user small  rm10"></i><?php the_author(); ?></div>
									<div class="gray-boxed verysmall gray leftfloat rm5 bm5"><i class="icon-comment small  rm10"></i><?php comments_popup_link('No comment','1 comment','% comments','pori','<span style="cursor:not-allowed;">Comments not allowed</span>'); ?></div>
									<div class="gray-boxed verysmall gray leftfloat rm5 bm5"><?php the_tags(); ?></div>
									<div class="clear"></div>
									<div class="divide30"></div>

								</article> <!-- END OF BLOG POST ARTICLE -->


							<?php endwhile; ?>
							<?php the_posts_pagination(array(

								'screen_reader_text'		=>' ',
								'prev_text'					=>'<button class="btn small gray withleftarrow"><span class="bold">Previous</span></button>',
								'next_text'					=>'<button class="btn small gray witharrow"><span class="bold">next</span></button>'

							)); ?>
								
								<div class="divide30"></div>

							<?php else: ?>
								<h1>OPPS! No Posts Found</h1>
							<?php endif; ?>




				</section> <!-- END OF THE CONTENT PART -->
				<!-- THE SIDEBAR -->
			<aside class="span3 graybg sidebar rightfloat">

				<?php get_sidebar(); ?>
			</aside>
			</div> <!-- END OF THE ROW CONTAINER -->

		</section><!-- END OF CONTAINER -->
	</section><!-- END OF CONTENT -->

 	</section> <!-- END OF MAIN CONTENT HERE -->

		<?php get_footer(); ?>

	