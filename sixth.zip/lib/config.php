<?php 


function amader_new_function_for_cmb2(){

	$ourbox= new_cmb2_box(array(

		'title'			=>__('contact Form','Sixth'),
		'id'			=>'contact-form',
		'object_types'	=>array('page')
	));
	$ourbox->add_field(array(

		'name'			=>__('Extra box','Sixth'),
		'id'			=>'contact-form',
		'type'			=>'text',
	));

	$onnobox=new_cmb2_box(array(

		'title'			=>'onno box',
		'id'			=>'onno-box',
		'object_types'	=>'page',
	));
	$onnobox->add_field(array(

		'name'			=>'text small',
		'id'			=>'text-small',
		'type'			=>'text_small',
	));

	// $onnobox->add_field(array(

	// 	'name'			=>'text email',
	// 	'id'			=>'text-email',
	// 	'type'			=>'text_email',
	// ));

	// $onnobox->add_field(array(

	// 	'name'			=>'text textarea',
	// 	'id'			=>'text-textarea',
	// 	'type'			=>'textarea',
	// ));

	// $onnobox->add_field(array(

	// 	'name'			=>'text textarea_code',
	// 	'id'			=>'text-textarea_code',
	// 	'type'			=>'textarea_code',
	// ));
	$onnobox->add_field(array(

		'name'			=>'text text_time',
		'id'			=>'text-text_time',
		'type'			=>'text_time',
		'before_field'	=>'&yen',
	));
	$onnobox->add_field(array(

		'name'			=>'text select_timezone',
		'id'			=>'text-select_timezone',
		'type'			=>'select_timezone',
	));
	$onnobox->add_field(array(

		'name'			=>'text colorpicker',
		'id'			=>'text-colorpicker',
		'type'			=>'colorpicker',
		'default'		=>'#ff00ff'
	));
	// $onnobox->add_field(array(

	// 	'name'			=>'text text_datetime_timestamp',
	// 	'id'			=>'text-text_datetime_timestamp',
	// 	'type'			=>'text_datetime_timestamp',
	// ));
	$onnobox->add_field(array(

		'name'			=>'text radio_inline',
		'id'			=>'text-radio_inline',
		'type'			=>'radio_inline',
		'show_option_none'=>true,
		'options'		=>array(

			'dhongi'	=>'dhong',
			'motu'		=>'motu',
			'moti'		=>'moti',
		),
	));
	$onnobox->add_field(array(

		'name'			=>'text checkbox',
		'id'			=>'text-checkbox',
		'type'			=>'checkbox',
	));
	$onnobox->add_field(array(

		'name'			=>'text file_list',
		'id'			=>'text-file_list',
		'type'			=>'file_list',
	));
	$onnobox->add_field(array(

		'name'			=>'text file',
		'id'			=>'text-file',
		'type'			=>'file',
	));
	$onnobox->add_field(array(

		'name'			=>'text wysiwyg',
		'id'			=>'text-wysiwyg',
		'type'			=>'wysiwyg',
	));
	$onnobox->add_field(array(

		'name'			=>'text oembed',
		'id'			=>'text-oembed',
		'type'			=>'oembed',
	));

}

add_action('cmb2_admin_init','amader_new_function_for_cmb2');
















 ?>